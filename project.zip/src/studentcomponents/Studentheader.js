import React from "react";
import "./Studentcss/Studentheader.css"
const Studentheader = () => {
    return (
        <div>
            <header>
                <nav>
                    <a class="jobs" href="/jobs" ><button>JOBS</button></a>
                    <a class="applied" href="/applied"><button>APPLIED</button></a>
                    <a class="forum" href="/forum"><button>FORUM</button></a>
                </nav>
            </header>
        </div>
    )
}

export default Studentheader;